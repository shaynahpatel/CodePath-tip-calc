//
//  ViewController.swift
//  CodePath Tip Calculator2
//
//  Created by Shayna Patel on 1/27/19.
//  Copyright © 2019 Shayna Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource

{
    
    var total = 0.00

    @IBOutlet weak var txtBillAmount: UITextField!
    @IBOutlet weak var sldTipPercent: UISlider!
    @IBOutlet weak var lblTipPercent: UILabel!
    @IBOutlet weak var lblTipAmount: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    
    @IBOutlet weak var lbl2ppl: UILabel!
    @IBOutlet weak var lbl3ppl: UILabel!
    @IBOutlet weak var lbl4ppl: UILabel!
    
    
    @IBOutlet weak var pckNumberOfSplits: UIPickerView!
    @IBOutlet weak var lblSplitCost: UILabel!
    
    let splits = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.pckNumberOfSplits.delegate = self
        self.pckNumberOfSplits.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func TipSlider(_ sender: Any) {
        let currentPercent = Int(sldTipPercent.value)
        lblTipPercent.text = "\(currentPercent)%"
        
        let bill = Double(txtBillAmount.text!) ?? 0
        let tipAmount = (bill * Double(currentPercent))/100
        let totalAmount = bill + tipAmount
        
        lblTipAmount.text = String(format: "$%.2f", tipAmount)
        lblTotalAmount.text = String (format: "$%.2f", totalAmount)
        lblSplitCost.text = String(format: "$%.2f", totalAmount)
        
        self.total = totalAmount
        
        //lbl2ppl.text = String(format: "$%.2f", totalAmount/2)
        
        //lbl3ppl.text = String(format: "$%.2f", totalAmount/3)
        
        //lbl4ppl.text = String(format: "$%.2f", totalAmount/4)
        
        
        
    }
    
    @IBAction func onTap(_ sender: Any) {
        view.endEditing(true) //dismisses keyboard when you click in background
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return splits.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(splits[row])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        updateSplitCost()
    }
    
    func updateSplitCost () {
        let numSplits = Double(self.pckNumberOfSplits.selectedRow(inComponent: 0) + 1)
        //let totalCost = Double(self.lblTotalAmount.text!) ?? 0
        let eachSplitCost = self.total/numSplits
        lblSplitCost.text = String(format: "$%.2f", eachSplitCost)
        print("updated")
        
    }
    
    @IBAction func onEditingChanged(sender: UIPickerView) {
        updateSplitCost()
    }
    
    
}

